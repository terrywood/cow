/*
SQLyog Job Agent v12.08 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 10.1.13-MariaDB : Database - cow
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`cow` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `cow`;

/*Table structure for table `account_daily` */

DROP TABLE IF EXISTS `account_daily`;

CREATE TABLE `account_daily` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountid` bigint(20) DEFAULT NULL,
  `day` datetime DEFAULT NULL,
  `equity` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

/*Data for the table `account_daily` */

insert  into `account_daily` values (1,5750720,'2016-07-13 00:00:00',2.5759),(2,4904532,'2016-07-13 00:00:00',3.0748),(3,3832417,'2016-07-13 00:00:00',1.8452),(4,6026528,'2016-07-13 00:00:00',1.8298),(5,6026380,'2016-07-13 00:00:00',1.835),(6,6028641,'2016-07-13 00:00:00',1.88),(7,6026400,'2016-07-13 00:00:00',2.0269),(8,5975300,'2016-07-13 00:00:00',2.5101),(9,5736249,'2016-07-13 00:00:00',1.9617),(10,3803325,'2016-07-13 00:00:00',2.33),(11,5061951,'2016-07-13 00:00:00',2.4369),(12,5701284,'2016-07-13 00:00:00',3.3522),(13,12153,'2016-07-13 00:00:00',4.0009),(14,98077,'2016-07-13 00:00:00',4.2531),(15,4096,'2016-07-13 00:00:00',4.4548),(16,16236,'2016-07-13 00:00:00',6.0239),(17,111517,'2016-07-13 00:00:00',6.4971),(18,5984990,'2016-07-13 00:00:00',0.9805),(19,5835775,'2016-07-13 00:00:00',2.8832),(20,4457629,'2016-07-13 00:00:00',9.5148),(21,4890303,'2016-07-13 00:00:00',2.7511),(22,5802162,'2016-07-13 00:00:00',4.8751),(23,10100,'2016-07-13 00:00:00',5.0956),(24,565784,'2016-07-13 00:00:00',3.5727),(25,773183,'2016-07-13 00:00:00',15.7532),(26,131984,'2016-07-13 00:00:00',12.2999),(27,605166,'2016-07-13 00:00:00',1.0411),(28,5750720,'2016-07-14 00:00:00',2.569),(29,4904532,'2016-07-14 00:00:00',3.0944),(30,3832417,'2016-07-14 00:00:00',1.8405),(31,6026528,'2016-07-14 00:00:00',1.9166),(32,6026380,'2016-07-14 00:00:00',1.8591),(33,6028641,'2016-07-14 00:00:00',1.8116),(34,6026400,'2016-07-14 00:00:00',2.0142),(35,5975300,'2016-07-14 00:00:00',2.5403),(36,5736249,'2016-07-14 00:00:00',1.9326),(37,3803325,'2016-07-14 00:00:00',2.3333),(38,5061951,'2016-07-14 00:00:00',2.6893),(39,5701284,'2016-07-14 00:00:00',3.3522),(40,12153,'2016-07-14 00:00:00',4.0243),(41,98077,'2016-07-14 00:00:00',4.221),(42,4096,'2016-07-14 00:00:00',4.4329),(43,16236,'2016-07-14 00:00:00',5.9919),(44,111517,'2016-07-14 00:00:00',6.5403),(45,5984990,'2016-07-14 00:00:00',0.9879),(46,5835775,'2016-07-14 00:00:00',2.8829),(47,4457629,'2016-07-14 00:00:00',9.7743),(48,4890303,'2016-07-14 00:00:00',2.7529),(49,5802162,'2016-07-14 00:00:00',5.0175),(50,10100,'2016-07-14 00:00:00',5.0881),(51,565784,'2016-07-14 00:00:00',3.5747),(52,773183,'2016-07-14 00:00:00',15.6206),(53,131984,'2016-07-14 00:00:00',12.3102),(54,605166,'2016-07-14 00:00:00',1.0421),(55,5750720,'2016-07-15 00:00:00',2.5171),(56,4904532,'2016-07-15 00:00:00',3.0616),(57,3832417,'2016-07-15 00:00:00',1.817),(58,6026528,'2016-07-15 00:00:00',1.9084),(59,6026380,'2016-07-15 00:00:00',1.8686),(60,6028641,'2016-07-15 00:00:00',1.8086),(61,6026400,'2016-07-15 00:00:00',1.9748),(62,5975300,'2016-07-15 00:00:00',2.575),(63,5736249,'2016-07-15 00:00:00',1.9133),(64,3803325,'2016-07-15 00:00:00',2.2942),(65,5061951,'2016-07-15 00:00:00',2.725),(66,5701284,'2016-07-15 00:00:00',3.3088),(67,12153,'2016-07-15 00:00:00',4.0421),(68,98077,'2016-07-15 00:00:00',4.2307),(69,4096,'2016-07-15 00:00:00',4.6317),(70,16236,'2016-07-15 00:00:00',5.9804),(71,111517,'2016-07-15 00:00:00',6.5928),(72,5984990,'2016-07-15 00:00:00',0.9697),(73,5835775,'2016-07-15 00:00:00',2.8777),(74,4457629,'2016-07-15 00:00:00',10.069),(75,4890303,'2016-07-15 00:00:00',2.7094),(76,5802162,'2016-07-15 00:00:00',4.9537),(77,10100,'2016-07-15 00:00:00',5.0283),(78,565784,'2016-07-15 00:00:00',3.5652),(79,773183,'2016-07-15 00:00:00',15.4734),(80,131984,'2016-07-15 00:00:00',12.13),(81,605166,'2016-07-15 00:00:00',1.0377);

/*Table structure for table `account_data` */

DROP TABLE IF EXISTS `account_data`;

CREATE TABLE `account_data` (
  `accountid` bigint(20) NOT NULL,
  `avaliable_asset` float DEFAULT NULL,
  `equity` float DEFAULT NULL,
  `first_trading_time` datetime DEFAULT NULL,
  `last_trading_time` datetime DEFAULT NULL,
  `logo_photo_url` varchar(255) DEFAULT NULL,
  `month_trade_number` float DEFAULT NULL,
  `month_yield` float DEFAULT NULL,
  `profit` float DEFAULT NULL,
  `retracement` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `today_profit` float DEFAULT NULL,
  `total_assets` float DEFAULT NULL,
  `trade_number` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `win_ratio` varchar(255) DEFAULT NULL,
  `yield_url` varchar(255) DEFAULT NULL,
  `avg_holding_day` float DEFAULT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account_data` */

insert  into `account_data` values (4096,296601,4.6317,'2014-08-29 13:39:53','2016-06-22 13:48:29','http://i0.niuguwang.com/SavePhoto/2014/0830/277/P_74F4A8B3A417F9509CE5F285F5666A99.jpg',0.83,15.88,3631650,'+1.07%',0,198755,4631650,19,'牵牛不开花','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=4096&h=0&w=0&v=_201607151530',28.58),(10100,682154,5.0283,'2014-06-23 14:32:13','2016-07-15 09:56:19','http://i0.niuguwang.com/SavePhoto/2015/0118/1798/P_D842D83E0F6999A38EA65792BF75FE87.jpg',2.36,16.05,4028250,'+6.64%',0,-59830.2,5028250,59,'赚钱赚厚','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=10100&h=0&w=0&v=_201607151530',17.58),(12153,2792220,4.0421,'2014-06-27 14:56:18','2016-07-15 13:53:11','http://i0.niuguwang.com/SavePhoto/2016/0205/19277/P_B83448334B98671066FF414BE56E9985.jpg',4.24,12.18,3042100,'+1.38%',0,22243.8,4042100,106,'每天乐呵呵','83.02','http://i1.niuguwang.com/yieldimage004.ashx?aid=12153&h=0&w=0&v=_201607151530',6.64),(16236,1427.26,5.9804,'2014-07-21 13:20:43','2016-07-15 09:43:36','http://i0.niuguwang.com/SavePhoto/2014/0906/288/P_9D4FBA46FB8CEF375E5B9021FA54D0AA.jpg',3.5,20.61,4980420,'+0.72%',0,-11469.3,5980420,84,'Jerome黄sir','73.81','http://i1.niuguwang.com/yieldimage004.ashx?aid=16236&h=0&w=0&v=_201607151530',13.56),(98077,57448,4.2307,'2014-10-10 10:10:17','2016-07-11 14:13:48','http://i0.niuguwang.com/SavePhoto/2015/0225/2572/P_2CB9821148E44388D91FFF7143D52685.jpg',0.95,15.05,3230690,'+1.21%',0,9704,4230690,21,'凉白开z','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=98077&h=0&w=0&v=_201607151530',32.95),(111517,1223.33,6.5928,'2014-10-20 09:56:17','2016-07-15 10:04:04','http://i0.niuguwang.com/SavePhoto/2016/0626/20625/P_CBC9C7FE19D0D62747BC6E632A908D96.jpg',2.38,26.46,5592760,'0%',0,52504.1,6592760,50,'★天外弦音☆','96','http://i1.niuguwang.com/yieldimage004.ashx?aid=111517&h=0&w=0&v=_201607151530',10.58),(131984,2013550,12.13,'2014-11-01 14:42:26','2016-07-08 14:29:02','http://i0.niuguwang.com/SavePhoto/2015/0102/1496/P_D204F4CB8EF9ED795971AD6DAD1E9CEF.jpg',6.76,53.68,11130000,'+68.7%',0,-180191,12130000,142,'龙飞虎','55.63','http://i1.niuguwang.com/yieldimage004.ashx?aid=131984&h=0&w=0&v=_201607151530',5.88),(565784,2736700,3.5652,'2015-02-06 15:09:27','2016-07-13 13:42:30','http://i0.niuguwang.com/SavePhoto/2015/0317/3210/P_59532E4FE41F474022009E028D6FFE59.jpg',4.78,14.66,2565200,'+0.27%',0,-9510,3565200,86,'Deepice','95.35','http://i1.niuguwang.com/yieldimage004.ashx?aid=565784&h=0&w=0&v=_201607151530',18.13),(605166,24867.8,1.0377,'2015-02-11 09:22:26','2016-07-14 10:05:25','http://i0.niuguwang.com/SavePhoto/2015/0210/2351/P_559F1F54040F57DA9688FE154715E98D.jpg',6,0.22,37658.2,'+22.21%',0,-5771,1037660,108,'★默默★','80.56','http://i1.niuguwang.com/yieldimage004.ashx?aid=605166&h=0&w=0&v=_201607151530',22.5),(773183,531.1,15.4734,'2015-03-10 22:47:52','2016-07-15 10:21:16','http://i0.niuguwang.com/SavePhoto/2015/1205/18247/P_0770C70FE0E3B8ECF509A53327EDAEB2.jpg',9.35,88.07,14473400,'+8.14%',0,-147176,15473400,159,'阿勤','74.84','http://i1.niuguwang.com/yieldimage004.ashx?aid=773183&h=0&w=0&v=_201607151530',2.78),(3803325,533.43,2.2942,'2015-10-08 10:47:21','2016-07-08 13:27:39','http://i0.niuguwang.com/SavePhoto/2015/0624/13225/P_634754A0A1BE4261C9E5F3ECF5DB2923.jpg',3.9,13.82,1294170,'+3.87%',0,-45612,2294170,39,'一字板online','76.92','http://i1.niuguwang.com/yieldimage004.ashx?aid=3803325&h=0&w=0&v=_201607151530',6.21),(3832417,4296.67,1.817,'2016-05-05 16:30:55','2016-07-14 10:10:40','http://i0.niuguwang.com/SavePhoto/2016/0707/20748/P_8D854D1D1E975F3A91B483969B906BD6.jpg',4,34.52,817017,'+1.59%',0,-23520,1817020,12,'展眉','83.33','http://i1.niuguwang.com/yieldimage004.ashx?aid=3832417&h=0&w=0&v=_201607151530',5.75),(4457629,1266.21,10.069,'2015-08-05 11:40:19','2016-07-15 11:18:38','http://i0.niuguwang.com/SavePhoto/2016/0202/19246/P_8984724972067E873F380C26FDAFCF85.jpg',7.75,78.86,9068980,'+9.25%',0,294716,10069000,93,'玩转股市小小文','83.87','http://i1.niuguwang.com/yieldimage004.ashx?aid=4457629&h=0&w=0&v=_201607151530',14.37),(4890303,1091120,2.7094,'2015-10-09 11:51:49','2016-07-13 09:55:08','http://i0.niuguwang.com/SavePhoto/2016/0303/19508/P_628A272FEB779A4238C4229830BB561E.jpg',0.8,18.32,1709410,'+1.74%',0,-43495,2709410,8,'我我们我们我','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=4890303&h=0&w=0&v=_201607151530',42),(4904532,673484,3.0616,'2016-01-15 11:44:15','2016-07-15 10:03:39','http://i0.niuguwang.com/SavePhoto/2016/0615/20517/P_68CDEE44C7DDB20148E1F968EF81B1A1.jpg',3.29,33.98,2061610,'+1.06%',0,-32757.2,3061610,23,'宁静泊淡','91.3','http://i1.niuguwang.com/yieldimage004.ashx?aid=4904532&h=0&w=0&v=_201607151530',12.65),(5061951,6083.32,2.725,'2016-01-15 13:29:32','2016-07-14 13:06:53','',2.14,28.43,1725030,'0%',0,35750,2725030,15,'一缕春风2015','86.67','http://i1.niuguwang.com/yieldimage004.ashx?aid=5061951&h=0&w=0&v=_201607151530',9.67),(5701284,214490,3.3088,'2016-01-18 16:11:42','2016-07-04 13:35:13','http://i0.niuguwang.com/SavePhoto/2016/0525/20337/P_8F8E25257A4AA07A4E24CA48BB8B45B8.jpg',3.33,38.7,2308820,'+1.29%',0,-43394,3308820,20,'从新开始了嗯哼','60','http://i1.niuguwang.com/yieldimage004.ashx?aid=5701284&h=0&w=0&v=_201607151530',9.55),(5736249,168029,1.9133,'2016-02-04 13:14:33','2016-07-06 14:44:00','http://i0.niuguwang.com/SavePhoto/2016/0613/20500/P_79701E10C5B0D0EFF843067585D5912E.jpg',2.33,16.91,913251,'+2.47%',0,-15064,1913250,14,'股市菜鸟到','85.71','http://i1.niuguwang.com/yieldimage004.ashx?aid=5736249&h=0&w=0&v=_201607151530',12.07),(5750720,53.31,2.5171,'2016-01-31 09:28:06','2016-07-13 09:31:28','http://i0.niuguwang.com/SavePhoto/2016/0629/20663/P_86CDE3ACC18A1ABFADEFB323E648323E.jpg',2.33,27.42,1517070,'+4.11%',0,-55395.2,2517070,14,'哥哥姓6','85.71','http://i1.niuguwang.com/yieldimage004.ashx?aid=5750720&h=0&w=0&v=_201607151530',12.07),(5802162,1050.47,4.9537,'2016-02-26 22:13:38','2016-07-15 09:58:58','http://i0.niuguwang.com/SavePhoto/2016/0604/20428/P_1AD1D6ED07B838B594D49197BAB333FD.jpg',13.4,84.72,3953660,'+2.29%',0,-63856.3,4953660,67,'宜兴新庄','64.18','http://i1.niuguwang.com/yieldimage004.ashx?aid=5802162&h=0&w=0&v=_201607151530',1.87),(5835775,1442850,2.8777,'2016-03-03 09:29:31','2016-07-14 14:42:58','http://i0.niuguwang.com/SavePhoto/2016/0529/20369/P_5A06C0AD854A4441A223D0380FB6E0E6.jpg',4.8,42.04,1877710,'+0.19%',0,-5180,2877710,24,'数控刀具','91.67','http://i1.niuguwang.com/yieldimage004.ashx?aid=5835775&h=0&w=0&v=_201607151530',4.96),(5975300,8532.03,2.575,'2016-04-18 22:01:43','2016-07-13 10:22:38','http://i0.niuguwang.com/SavePhoto/2016/0523/20322/P_64A6DC810D87E98757F1E18D8BFA6F1B.jpg',8.67,53.69,1575010,'0%',0,34720,2575010,26,'大股为','69.23','http://i1.niuguwang.com/yieldimage004.ashx?aid=5975300&h=0&w=0&v=_201607151530',4.65),(5984990,5062.08,0.9697,'2016-04-21 09:15:44','2016-07-15 14:55:47','http://i0.niuguwang.com/SavePhoto/2016/0420/20032/P_1FF0DE8FDB362B66FEA78D316B4480FB.jpg',21.67,-1.07,-30281.9,'+6.13%',0,-18190,969718,65,'牛营战法','70.77','http://i1.niuguwang.com/yieldimage004.ashx?aid=5984990&h=0&w=0&v=_201607151530',2.6),(6026380,2456.16,1.8686,'2016-05-10 13:23:12','2016-07-15 14:56:59','http://i0.niuguwang.com/SavePhoto/2016/0509/20197/P_22FA12D7E829D0BF9E333582679B5FE7.jpg',6.33,39.48,868606,'0%',0,9512.69,1868610,19,'小天飞神','84.21','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026380&h=0&w=0&v=_201607151530',4.95),(6026400,137844,1.9748,'2016-05-10 09:35:48','2016-07-11 13:57:45','',1.33,44.31,974780,'+5.27%',0,-39432,1974780,4,'搞搞骏','75','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026400&h=0&w=0&v=_201607151530',15.5),(6026528,29220.5,1.9084,'2016-05-10 11:01:53','2016-07-11 10:26:28','',2.33,41.29,908420,'+0.43%',0,-8149,1908420,7,'乘云望月2','71.43','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026528&h=0&w=0&v=_201607151530',14.57),(6028641,3842.39,1.8086,'2016-05-11 09:36:43','2016-07-15 14:05:03','',7,37.32,808579,'+3.8%',0,-3027.6,1808580,21,'天下贵位','57.14','http://i1.niuguwang.com/yieldimage004.ashx?aid=6028641&h=0&w=0&v=_201607151530',3.38);

/*Table structure for table `history_data` */

DROP TABLE IF EXISTS `history_data`;

CREATE TABLE `history_data` (
  `delegateid` bigint(20) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `listid` bigint(20) DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_unit_price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  PRIMARY KEY (`delegateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `history_data` */

/*Table structure for table `stock_list_data` */

DROP TABLE IF EXISTS `stock_list_data`;

CREATE TABLE `stock_list_data` (
  `listid` bigint(20) NOT NULL,
  `accountid` varchar(255) DEFAULT NULL,
  `action_amount` int(11) DEFAULT NULL,
  `last_trading_time` datetime DEFAULT NULL,
  `market` varchar(255) DEFAULT NULL,
  `stock_code` varchar(255) DEFAULT NULL,
  `stock_name` varchar(255) DEFAULT NULL,
  `unit_price` float DEFAULT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `stock_list_data` */

/*Table structure for table `trader` */

DROP TABLE IF EXISTS `trader`;

CREATE TABLE `trader` (
  `delegateid` bigint(20) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `fast` bit(1) DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_unit_price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`delegateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `trader` */

/*Table structure for table `trader_session` */

DROP TABLE IF EXISTS `trader_session`;

CREATE TABLE `trader_session` (
  `sid` varchar(255) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `cookie` varchar(500) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sh_account` varchar(255) DEFAULT NULL,
  `sz_account` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `trader_session` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
