/*
SQLyog Job Agent v12.08 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 10.1.13-MariaDB : Database - cow
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`cow` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `cow`;

/*Table structure for table `account_daily` */

DROP TABLE IF EXISTS `account_daily`;

CREATE TABLE `account_daily` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountid` bigint(20) DEFAULT NULL,
  `day` datetime DEFAULT NULL,
  `equity` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

/*Data for the table `account_daily` */

insert  into `account_daily` values (1,5750720,'2016-07-13 00:00:00',2.5759),(2,4904532,'2016-07-13 00:00:00',3.0748),(3,3832417,'2016-07-13 00:00:00',1.8452),(4,6026528,'2016-07-13 00:00:00',1.8298),(5,6026380,'2016-07-13 00:00:00',1.835),(6,6028641,'2016-07-13 00:00:00',1.88),(7,6026400,'2016-07-13 00:00:00',2.0269),(8,5975300,'2016-07-13 00:00:00',2.5101),(9,5736249,'2016-07-13 00:00:00',1.9617),(10,3803325,'2016-07-13 00:00:00',2.33),(11,5061951,'2016-07-13 00:00:00',2.4369),(12,5701284,'2016-07-13 00:00:00',3.3522),(13,12153,'2016-07-13 00:00:00',4.0009),(14,98077,'2016-07-13 00:00:00',4.2531),(15,4096,'2016-07-13 00:00:00',4.4548),(16,16236,'2016-07-13 00:00:00',6.0239),(17,111517,'2016-07-13 00:00:00',6.4971),(18,5984990,'2016-07-13 00:00:00',0.9805),(19,5835775,'2016-07-13 00:00:00',2.8832),(20,4457629,'2016-07-13 00:00:00',9.5148),(21,4890303,'2016-07-13 00:00:00',2.7511),(22,5802162,'2016-07-13 00:00:00',4.8751),(23,10100,'2016-07-13 00:00:00',5.0956),(24,565784,'2016-07-13 00:00:00',3.5727),(25,773183,'2016-07-13 00:00:00',15.7532),(26,131984,'2016-07-13 00:00:00',12.2999),(27,605166,'2016-07-13 00:00:00',1.0411),(28,5750720,'2016-07-14 00:00:00',2.569),(29,4904532,'2016-07-14 00:00:00',3.0944),(30,3832417,'2016-07-14 00:00:00',1.8405),(31,6026528,'2016-07-14 00:00:00',1.9166),(32,6026380,'2016-07-14 00:00:00',1.8591),(33,6028641,'2016-07-14 00:00:00',1.8116),(34,6026400,'2016-07-14 00:00:00',2.0142),(35,5975300,'2016-07-14 00:00:00',2.5403),(36,5736249,'2016-07-14 00:00:00',1.9326),(37,3803325,'2016-07-14 00:00:00',2.3333),(38,5061951,'2016-07-14 00:00:00',2.6893),(39,5701284,'2016-07-14 00:00:00',3.3522),(40,12153,'2016-07-14 00:00:00',4.0243),(41,98077,'2016-07-14 00:00:00',4.221),(42,4096,'2016-07-14 00:00:00',4.4329),(43,16236,'2016-07-14 00:00:00',5.9919),(44,111517,'2016-07-14 00:00:00',6.5403),(45,5984990,'2016-07-14 00:00:00',0.9879),(46,5835775,'2016-07-14 00:00:00',2.8829),(47,4457629,'2016-07-14 00:00:00',9.7743),(48,4890303,'2016-07-14 00:00:00',2.7529),(49,5802162,'2016-07-14 00:00:00',5.0175),(50,10100,'2016-07-14 00:00:00',5.0881),(51,565784,'2016-07-14 00:00:00',3.5747),(52,773183,'2016-07-14 00:00:00',15.6206),(53,131984,'2016-07-14 00:00:00',12.3102),(54,605166,'2016-07-14 00:00:00',1.0421);

/*Table structure for table `account_data` */

DROP TABLE IF EXISTS `account_data`;

CREATE TABLE `account_data` (
  `accountid` bigint(20) NOT NULL,
  `avaliable_asset` float DEFAULT NULL,
  `equity` float DEFAULT NULL,
  `first_trading_time` datetime DEFAULT NULL,
  `last_trading_time` datetime DEFAULT NULL,
  `logo_photo_url` varchar(255) DEFAULT NULL,
  `month_trade_number` float DEFAULT NULL,
  `month_yield` float DEFAULT NULL,
  `profit` float DEFAULT NULL,
  `retracement` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `today_profit` float DEFAULT NULL,
  `total_assets` float DEFAULT NULL,
  `trade_number` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `win_ratio` varchar(255) DEFAULT NULL,
  `yield_url` varchar(255) DEFAULT NULL,
  `avg_holding_day` float DEFAULT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `account_data` */

insert  into `account_data` values (4096,296601,4.4329,'2014-08-29 13:39:53','2016-06-22 13:48:29','http://i0.niuguwang.com/SavePhoto/2014/0830/277/P_74F4A8B3A417F9509CE5F285F5666A99.jpg',0.83,15.03,3432900,'+5.32%',0,-21910,4432900,19,'牵牛不开花','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=4096&h=0&w=0&v=_201607141500',28.58),(10100,679456,5.0881,'2014-06-23 14:32:13','2016-07-14 13:39:03','http://i0.niuguwang.com/SavePhoto/2015/0118/1798/P_D842D83E0F6999A38EA65792BF75FE87.jpg',2.36,16.31,4088080,'+5.53%',0,-7527.05,5088080,59,'赚钱赚厚','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=10100&h=0&w=0&v=_201607141500',17.58),(12153,1572020,4.0243,'2014-06-27 14:56:18','2016-07-14 13:53:13','http://i0.niuguwang.com/SavePhoto/2016/0205/19277/P_B83448334B98671066FF414BE56E9985.jpg',4.2,12.13,3024330,'+1.81%',0,23473,4024330,105,'每天乐呵呵','82.86','http://i1.niuguwang.com/yieldimage004.ashx?aid=12153&h=0&w=0&v=_201607141500',6.7),(16236,153.54,5.9919,'2014-07-21 13:20:43','2016-07-13 09:47:36','http://i0.niuguwang.com/SavePhoto/2014/0906/288/P_9D4FBA46FB8CEF375E5B9021FA54D0AA.jpg',3.46,20.68,4991880,'+0.53%',0,-32016,5991880,83,'Jerome黄sir','73.49','http://i1.niuguwang.com/yieldimage004.ashx?aid=16236&h=0&w=0&v=_201607141500',13.67),(98077,57448,4.221,'2014-10-10 10:10:17','2016-07-11 14:13:48','http://i0.niuguwang.com/SavePhoto/2015/0225/2572/P_2CB9821148E44388D91FFF7143D52685.jpg',0.95,15.03,3220990,'+1.44%',0,-32085,4220990,21,'凉白开z','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=98077&h=0&w=0&v=_201607141500',32.95),(111517,864.27,6.5403,'2014-10-20 09:56:17','2016-07-07 10:03:00','http://i0.niuguwang.com/SavePhoto/2016/0626/20625/P_CBC9C7FE19D0D62747BC6E632A908D96.jpg',2.38,26.26,5540260,'0%',0,43177,6540260,50,'★天外弦音☆','96','http://i1.niuguwang.com/yieldimage004.ashx?aid=111517&h=0&w=0&v=_201607141500',10.58),(131984,2013550,12.3102,'2014-11-01 14:42:26','2016-07-08 14:29:02','http://i0.niuguwang.com/SavePhoto/2015/0102/1496/P_D204F4CB8EF9ED795971AD6DAD1E9CEF.jpg',6.76,54.64,11310200,'+68.24%',0,10296.6,12310200,142,'龙飞虎','55.63','http://i1.niuguwang.com/yieldimage004.ashx?aid=131984&h=0&w=0&v=_201607141500',5.88),(565784,2736460,3.5747,'2015-02-06 15:09:27','2016-07-13 13:42:30','http://i0.niuguwang.com/SavePhoto/2015/0317/3210/P_59532E4FE41F474022009E028D6FFE59.jpg',4.78,14.74,2574710,'0%',0,2000,3574710,86,'Deepice','95.35','http://i1.niuguwang.com/yieldimage004.ashx?aid=565784&h=0&w=0&v=_201607141500',18.13),(605166,24867.8,1.0421,'2015-02-11 09:22:26','2016-07-14 10:05:25','http://i0.niuguwang.com/SavePhoto/2015/0210/2351/P_559F1F54040F57DA9688FE154715E98D.jpg',6,0.24,42102.2,'+21.88%',0,985.64,1042100,108,'★默默★','80.56','http://i1.niuguwang.com/yieldimage004.ashx?aid=605166&h=0&w=0&v=_201607141500',22.5),(773183,317.07,15.6206,'2015-03-10 22:47:52','2016-07-12 14:22:42','http://i0.niuguwang.com/SavePhoto/2015/1205/18247/P_0770C70FE0E3B8ECF509A53327EDAEB2.jpg',9.29,89.15,14620600,'+7.27%',0,-132600,15620600,158,'阿勤','75.32','http://i1.niuguwang.com/yieldimage004.ashx?aid=773183&h=0&w=0&v=_201607141500',2.77),(3803325,533.43,2.3333,'2015-10-08 10:47:21','2016-07-08 13:27:39','http://i0.niuguwang.com/SavePhoto/2015/0624/13225/P_634754A0A1BE4261C9E5F3ECF5DB2923.jpg',3.9,14.28,1333260,'+2.23%',0,3258,2333260,39,'一字板online','76.92','http://i1.niuguwang.com/yieldimage004.ashx?aid=3803325&h=0&w=0&v=_201607141500',6.21),(3832417,4296.67,1.8405,'2016-05-05 16:30:55','2016-07-14 10:10:40','http://i0.niuguwang.com/SavePhoto/2016/0707/20748/P_8D854D1D1E975F3A91B483969B906BD6.jpg',4,36.02,840537,'+0.32%',0,-4696.84,1840540,12,'展眉','83.33','http://i1.niuguwang.com/yieldimage004.ashx?aid=3832417&h=0&w=0&v=_201607141500',5.75),(4457629,646.82,9.7743,'2015-08-05 11:40:19','2016-07-14 10:15:56','http://i0.niuguwang.com/SavePhoto/2016/0202/19246/P_8984724972067E873F380C26FDAFCF85.jpg',7.58,76.52,8774270,'+11.9%',0,259469,9774270,91,'玩转股市小小文','84.62','http://i1.niuguwang.com/yieldimage004.ashx?aid=4457629&h=0&w=0&v=_201607141500',14.66),(4890303,1091120,2.7529,'2015-10-09 11:51:49','2016-07-13 09:55:08','http://i0.niuguwang.com/SavePhoto/2016/0303/19508/P_628A272FEB779A4238C4229830BB561E.jpg',0.8,18.85,1752900,'+0.16%',0,1790,2752900,8,'我我们我们我','100','http://i1.niuguwang.com/yieldimage004.ashx?aid=4890303&h=0&w=0&v=_201607141500',42),(4904532,894419,3.0944,'2016-01-15 11:44:15','2016-07-14 10:48:05','http://i0.niuguwang.com/SavePhoto/2016/0615/20517/P_68CDEE44C7DDB20148E1F968EF81B1A1.jpg',3.83,34.71,2094360,'0%',0,19543.4,3094360,23,'宁静泊淡','91.3','http://i1.niuguwang.com/yieldimage004.ashx?aid=4904532&h=0&w=0&v=_201607141500',12.65),(5061951,6083.32,2.6893,'2016-01-15 13:29:32','2016-07-14 13:06:53','',2.5,28,1689280,'0%',0,252355,2689280,15,'一缕春风2015','86.67','http://i1.niuguwang.com/yieldimage004.ashx?aid=5061951&h=0&w=0&v=_201607141500',9.67),(5701284,214490,3.3522,'2016-01-18 16:11:42','2016-07-04 13:35:13','http://i0.niuguwang.com/SavePhoto/2016/0525/20337/P_8F8E25257A4AA07A4E24CA48BB8B45B8.jpg',3.33,39.64,2352210,'0%',0,0,3352210,20,'从新开始了嗯哼','60','http://i1.niuguwang.com/yieldimage004.ashx?aid=5701284&h=0&w=0&v=_201607141500',9.55),(5736249,168029,1.9326,'2016-02-04 13:14:33','2016-07-06 14:44:00','http://i0.niuguwang.com/SavePhoto/2016/0613/20500/P_79701E10C5B0D0EFF843067585D5912E.jpg',2.33,17.38,932619,'+1.48%',0,-29052,1932620,14,'股市菜鸟到','85.71','http://i1.niuguwang.com/yieldimage004.ashx?aid=5736249&h=0&w=0&v=_201607141500',12.07),(5750720,53.31,2.569,'2016-01-31 09:28:06','2016-07-13 09:31:28','http://i0.niuguwang.com/SavePhoto/2016/0629/20663/P_86CDE3ACC18A1ABFADEFB323E648323E.jpg',2.33,28.53,1569010,'+2.14%',0,-6924.4,2569010,14,'哥哥姓6','85.71','http://i1.niuguwang.com/yieldimage004.ashx?aid=5750720&h=0&w=0&v=_201607141500',12.07),(5802162,797.77,5.0175,'2016-02-26 22:13:38','2016-07-14 13:19:46','http://i0.niuguwang.com/SavePhoto/2016/0604/20428/P_1AD1D6ED07B838B594D49197BAB333FD.jpg',13.2,86.71,4017520,'+1.03%',0,142409,5017520,66,'宜兴新庄','63.64','http://i1.niuguwang.com/yieldimage004.ashx?aid=5802162&h=0&w=0&v=_201607141500',1.88),(5835775,1442850,2.8829,'2016-03-03 09:29:31','2016-07-14 14:42:58','http://i0.niuguwang.com/SavePhoto/2016/0529/20369/P_5A06C0AD854A4441A223D0380FB6E0E6.jpg',4.8,42.47,1882890,'+0.01%',0,-360.01,2882890,24,'数控刀具','91.67','http://i1.niuguwang.com/yieldimage004.ashx?aid=5835775&h=0&w=0&v=_201607141500',4.96),(5975300,8532.03,2.5403,'2016-04-18 22:01:43','2016-07-13 10:22:38','http://i0.niuguwang.com/SavePhoto/2016/0523/20322/P_64A6DC810D87E98757F1E18D8BFA6F1B.jpg',8.67,53.11,1540290,'0%',0,30240,2540290,26,'大股为','69.23','http://i1.niuguwang.com/yieldimage004.ashx?aid=5975300&h=0&w=0&v=_201607141500',4.65),(5984990,45204.1,0.9879,'2016-04-21 09:15:44','2016-07-14 10:16:52','http://i0.niuguwang.com/SavePhoto/2016/0420/20032/P_1FF0DE8FDB362B66FEA78D316B4480FB.jpg',21.33,-0.43,-12091.9,'+4.37%',0,7381.36,987908,64,'牛营战法','71.88','http://i1.niuguwang.com/yieldimage004.ashx?aid=5984990&h=0&w=0&v=_201607141500',2.42),(6026380,1871.47,1.8591,'2016-05-10 13:23:12','2016-07-14 14:53:43','http://i0.niuguwang.com/SavePhoto/2016/0509/20197/P_22FA12D7E829D0BF9E333582679B5FE7.jpg',5.67,39.65,859094,'0%',0,24079.8,1859090,17,'小天飞神','88.24','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026380&h=0&w=0&v=_201607141500',5.35),(6026400,137844,2.0142,'2016-05-10 09:35:48','2016-07-11 13:57:45','',1.33,46.81,1014210,'+3.38%',0,-12648,2014210,4,'搞搞骏','75','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026400&h=0&w=0&v=_201607141500',15.5),(6026528,29220.5,1.9166,'2016-05-10 11:01:53','2016-07-11 10:26:28','',2.33,42.3,916570,'0%',0,86797,1916570,7,'乘云望月2','71.43','http://i1.niuguwang.com/yieldimage004.ashx?aid=6026528&h=0&w=0&v=_201607141500',14.57),(6028641,2136,1.8116,'2016-05-11 09:36:43','2016-07-14 10:11:22','',6.67,38.04,811607,'+3.64%',0,-68376.8,1811610,20,'天下贵位','60','http://i1.niuguwang.com/yieldimage004.ashx?aid=6028641&h=0&w=0&v=_201607141500',3.5);

/*Table structure for table `history_data` */

DROP TABLE IF EXISTS `history_data`;

CREATE TABLE `history_data` (
  `delegateid` bigint(20) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  `listid` bigint(20) DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_unit_price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`delegateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `history_data` */

/*Table structure for table `stock_list_data` */

DROP TABLE IF EXISTS `stock_list_data`;

CREATE TABLE `stock_list_data` (
  `listid` bigint(20) NOT NULL,
  `accountid` varchar(255) DEFAULT NULL,
  `action_amount` int(11) DEFAULT NULL,
  `last_trading_time` datetime DEFAULT NULL,
  `market` varchar(255) DEFAULT NULL,
  `stock_code` varchar(255) DEFAULT NULL,
  `stock_name` varchar(255) DEFAULT NULL,
  `unit_price` float DEFAULT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `stock_list_data` */

/*Table structure for table `trader` */

DROP TABLE IF EXISTS `trader`;

CREATE TABLE `trader` (
  `delegateid` bigint(20) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `fast` bit(1) DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `transaction_amount` int(11) DEFAULT NULL,
  `transaction_unit_price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`delegateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `trader` */

/*Table structure for table `trader_session` */

DROP TABLE IF EXISTS `trader_session`;

CREATE TABLE `trader_session` (
  `sid` varchar(255) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `cookie` varchar(500) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sh_account` varchar(255) DEFAULT NULL,
  `sz_account` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `trader_session` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
